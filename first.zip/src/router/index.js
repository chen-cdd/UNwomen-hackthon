import { createRouter, createWebHistory } from 'vue-router'
import RealTimeHealthSupport from '../components/RealTimeHealthSupport.vue'
import AskSani from '../components/AskSani.vue'

const routes = [
  // ... 其他路由 ...
  {
    path: '/real-time-health-support',
    name: 'RealTimeHealthSupport',
    component: RealTimeHealthSupport
  },
  {
    path: '/ask-sani',
    name: 'AskSani',
    component: AskSani
  },
]

// ... 其他路由配置 ...