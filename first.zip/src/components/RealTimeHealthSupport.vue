<template>
  <div class="real-time-health-support gradient-bg">
    <div class="header">
      <h1 class="gradient-text">Real-time Health Support</h1>
      <p>Get instant access to medical consultations and appointments. Your health matters.</p>
      
      <div class="upcoming-appointment" :class="{ 'no-appointment': !hasAppointment }">
        <div class="appointment-status">
          <i class="status-icon">{{ hasAppointment ? '📅' : '⚠️' }}</i>
          <div class="status-text">
            <h3>{{ hasAppointment ? 'Upcoming Appointment' : 'No Scheduled Appointments' }}</h3>
            <p v-if="hasAppointment">
              {{ nextAppointment.doctor }} - {{ nextAppointment.date }}
            </p>
            <p v-else>Schedule your first appointment below</p>
          </div>
        </div>
      </div>
    </div>
    
    <div class="dashboard">
      <div class="left-panel">
        <div class="appointment-form">
          <h2>Book an Appointment</h2>
          <label for="reason">Department</label>
          <select id="reason" v-model="selectedReason">
            <option disabled value="">Select department...</option>
            <option>Gynecology</option>
            <option>Endocrinology</option>
            <option>Mental Health</option>
            <option>Traditional Chinese Medicine</option>
          </select>
          <label for="notes">Notes</label>
          <textarea 
            id="notes" 
            v-model="notes" 
            placeholder="Add any notes about your visit..."
            rows="3"
          ></textarea>
          <label for="name">Full Name</label>
          <input type="text" id="name" v-model="name" placeholder="Enter your name" />
          <label for="email">Email Address</label>
          <input type="email" id="email" v-model="email" placeholder="Enter your email" />
          <label for="phone">Phone Number</label>
          <input type="tel" id="phone" v-model="phone" placeholder="Enter your phone number" />
        </div>
      </div>
      <div class="right-panel">
        <div class="available-doctors">
          <h2>Available Doctors</h2>
          <div class="doctor-list">
            <div v-for="doctor in doctors" :key="doctor.doctor_id" class="doctor-card">
              <div class="doctor-info">
                <div class="doctor-avatar">👩‍⚕️</div>
                <div class="doctor-details">
                  <strong>Dr. {{ doctor.name }}</strong>
                  <span>{{ doctor.specialty }}</span>
                  <div class="availability">
                    Available: {{ formatAvailability(doctor.availability) }}
                  </div>
                </div>
              </div>
              <button 
                @click="selectDoctor(doctor)" 
                :class="['select-button', { selected: selectedDoctor?.doctor_id === doctor.doctor_id }]"
              >
                {{ selectedDoctor?.doctor_id === doctor.doctor_id ? 'Selected' : 'Select' }}
              </button>
            </div>
          </div>
        </div>
      
      <!-- Time Selection Section -->
      <div v-if="selectedDoctor" class="time-selection">
        <h3>Select Appointment Time</h3>
        <div class="date-picker">
          <label for="appointment-date">Date:</label>
          <input 
            type="date" 
            id="appointment-date" 
            v-model="selectedDate"
            :min="minDate"
            @change="updateAvailableTimeSlots"
          />
        </div>
        <div class="time-slots" v-if="selectedDate">
          <div 
            v-for="slot in availableTimeSlots" 
            :key="slot.time"
            :class="['time-slot', { 
              'available': slot.available,
              'selected': selectedTime === slot.time 
            }]"
            @click="slot.available && selectTimeSlot(slot.time)"
          >
            {{ slot.time }}
          </div>
        </div>
      </div>
      <!-- Book Appointment Button -->
      <button 
        class="book-appointment-button" 
        :disabled="!canBook"
        @click="bookAppointment"
      >
        Book Appointment
      </button>
    </div>
  </div>
</div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'RealTimeHealthSupport',
  data() {
    return {
      selectedReason: '',
      name: '',
      email: '',
      phone: '',
      notes: '',
      hasAppointment: false,
      selectedDoctor: null,
      selectedDate: null,
      selectedTime: null,
      nextAppointment: {
        doctor: '',
        date: ''
      },
      doctors: [
        { 
          doctor_id: 1, 
          name: 'Smith', 
          specialty: 'Gynecology',
          availability: {
            "Monday": "9:00-17:00",
            "Wednesday": "9:00-17:00"
          }
        },
        { 
          doctor_id: 2, 
          name: 'Johnson', 
          specialty: 'Endocrinology',
          availability: {
            "Tuesday": "9:00-17:00",
            "Thursday": "9:00-17:00"
          }
        },
        { 
          doctor_id: 3, 
          name: 'Williams', 
          specialty: 'Gynecology',
          availability: {
            "Monday": "9:00-17:00",
            "Friday": "9:00-17:00"
          }
        },
        { 
          doctor_id: 4, 
          name: 'Brown', 
          specialty: 'Mental Health',
          availability: {
            "Wednesday": "9:00-17:00",
            "Friday": "9:00-17:00"
          }
        },
        { 
          doctor_id: 5, 
          name: 'Davis', 
          specialty: 'Traditional Chinese Medicine',
          availability: {
            "Tuesday": "9:00-17:00",
            "Thursday": "9:00-17:00"
          }
        }
      ],
      availableTimeSlots: []
    };
  },
  computed: {
    minDate() {
      const today = new Date();
      return today.toISOString().split('T')[0];
    },
    canBook() {
      return this.selectedDoctor && 
             this.selectedDate && 
             this.selectedTime && 
             this.name && 
             this.email;
    }
  },
  methods: {
    formatAvailability(availability) {
      if (!availability) return 'Schedule not available';
      return Object.entries(availability)
        .map(([day, time]) => `${day}: ${time}`)
        .join(', ');
    },
    selectDoctor(doctor) {
      this.selectedDoctor = doctor;
      this.selectedDate = null;
      this.selectedTime = null;
      this.availableTimeSlots = [];
    },
    updateAvailableTimeSlots() {
      // Generate available time slots based on selected date and doctor's availability
      const timeSlots = [];
      const start = 9;
      const end = 17;
      
      for (let hour = start; hour < end; hour++) {
        timeSlots.push({
          time: `${hour}:00`,
          available: true
        });
      }
      
      this.availableTimeSlots = timeSlots;
    },
    selectTimeSlot(time) {
      this.selectedTime = time;
    },
    async bookAppointment() {
      if (!this.canBook) return;

      try {
        const appointmentData = {
          user_id: 1, // Should be actual user ID
          doctor_id: this.selectedDoctor.doctor_id,
          appointment_date: `${this.selectedDate} ${this.selectedTime}:00`,
          status: 'scheduled',
          notes: this.notes
        };

        const response = await axios.post('http://localhost:5000/api/appointments', appointmentData);

        if (response.data.success) {
          this.hasAppointment = true;
          this.nextAppointment = {
            doctor: `Dr. ${this.selectedDoctor.name}`,
            date: `${this.selectedDate} ${this.selectedTime}`
          };
          alert('Appointment booked successfully!');
        }
      } catch (error) {
        console.error('Error booking appointment:', error);
        alert('Failed to book appointment. Please try again.');
      }
    }
  }
}
</script>

<style scoped>
.gradient-bg {
  background: #ffffff;
  min-height: 100vh;
}

.real-time-health-support {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
}

.gradient-text {
  font-size: 2.5rem;
  text-align: center;
  margin-bottom: 1rem;
  background: linear-gradient(135deg, #d53f8c, #805ad5);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  position: relative;
  padding-bottom: 1rem;
}

.gradient-text::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 100px;
  height: 4px;
  background: linear-gradient(90deg, #d53f8c, #805ad5);
  border-radius: 2px;
}

.header {
  text-align: center;
  margin-bottom: 3rem;
}

.header p {
  color: #4a5568;
  font-size: 1.2rem;
  margin-bottom: 2rem;
  max-width: 800px;
  margin: 0 auto 2rem;
}

.upcoming-appointment {
  background: white;
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 8px 30px rgba(213, 63, 140, 0.1);
  margin: 0 auto;
  max-width: 600px;
  border: 1px solid rgba(213, 63, 140, 0.1);
  transition: all 0.3s ease;
}

.upcoming-appointment:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 40px rgba(213, 63, 140, 0.15);
}

.appointment-status {
  display: flex;
  align-items: center;
  gap: 2rem;
}

.status-icon {
  font-size: 3rem;
  background: linear-gradient(135deg, #fff0f6, #faf5ff);
  width: 80px;
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
}

.status-text h3 {
  color: #2d3748;
  margin-bottom: 0.8rem;
  font-size: 1.4rem;
}

.status-text p {
  color: #4a5568;
  font-size: 1.1rem;
}

.no-appointment {
  background: #fff5f5;
  border-color: rgba(229, 62, 62, 0.1);
}

.dashboard {
  display: flex;
  gap: 2rem;
  margin-top: 3rem;
}

.left-panel, .right-panel {
  flex: 1;
  background: white;
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 8px 30px rgba(213, 63, 140, 0.1);
  border: 1px solid rgba(213, 63, 140, 0.1);
}

.appointment-form {
  display: flex;
  flex-direction: column;
}

.appointment-form h2 {
  margin-bottom: 2rem;
  color: #2d3748;
  font-size: 1.8rem;
}

label {
  margin: 0.8rem 0;
  color: #2d3748;
  font-weight: 500;
}

select, input, textarea {
  width: 100%;
  padding: 1rem;
  margin-bottom: 1.5rem;
  border: 2px solid rgba(213, 63, 140, 0.2);
  border-radius: 12px;
  transition: all 0.3s ease;
  font-size: 1rem;
}

select:focus, input:focus, textarea:focus {
  outline: none;
  border-color: #d53f8c;
  box-shadow: 0 0 0 3px rgba(213, 63, 140, 0.1);
}

.doctor-list {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.doctor-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  background: white;
  border-radius: 15px;
  transition: all 0.3s ease;
  border: 1px solid rgba(213, 63, 140, 0.1);
}

.doctor-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 40px rgba(213, 63, 140, 0.15);
}

.doctor-info {
  display: flex;
  align-items: center;
  gap: 1.5rem;
}

.doctor-avatar {
  font-size: 2.5rem;
  background: linear-gradient(135deg, #fff0f6, #faf5ff);
  width: 60px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
}

.doctor-details {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.doctor-details strong {
  color: #2d3748;
  font-size: 1.2rem;
}

.doctor-details span {
  color: #4a5568;
  font-size: 1rem;
}

.time-selection {
  margin-top: 2rem;
  padding: 2rem;
  background: white;
  border-radius: 20px;
  box-shadow: 0 8px 30px rgba(213, 63, 140, 0.1);
  border: 1px solid rgba(213, 63, 140, 0.1);
}

.time-selection h3 {
  color: #2d3748;
  margin-bottom: 1.5rem;
  font-size: 1.4rem;
}

.date-picker {
  margin-bottom: 1.5rem;
}

.time-slots {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 1rem;
  padding: 1.5rem;
  background: linear-gradient(135deg, #fff0f6, #faf5ff);
  border-radius: 15px;
}

.time-slot {
  padding: 1rem;
  text-align: center;
  border-radius: 12px;
  font-weight: 500;
  transition: all 0.3s ease;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
}

.time-slot.available {
  background: white;
  color: #d53f8c;
  border: 2px solid rgba(213, 63, 140, 0.2);
}

.time-slot.available:hover {
  background: linear-gradient(135deg, #d53f8c, #805ad5);
  color: white;
  transform: translateY(-3px);
  box-shadow: 0 8px 20px rgba(213, 63, 140, 0.2);
  border-color: transparent;
}

.time-slot.selected {
  background: linear-gradient(135deg, #d53f8c, #805ad5);
  color: white;
  border-color: transparent;
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(213, 63, 140, 0.2);
}

.time-slot:not(.available) {
  background: #f7fafc;
  color: #a0aec0;
  border: 2px solid #edf2f7;
  cursor: not-allowed;
  opacity: 0.8;
}

.book-appointment-button {
  width: 100%;
  margin-top: 2rem;
  padding: 1.2rem;
  background: linear-gradient(135deg, #d53f8c, #805ad5);
  color: white;
  border: none;
  border-radius: 12px;
  cursor: pointer;
  font-size: 1.1rem;
  font-weight: 600;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(213, 63, 140, 0.2);
}

.book-appointment-button:hover:not(:disabled) {
  transform: translateY(-3px);
  box-shadow: 0 8px 25px rgba(213, 63, 140, 0.3);
}

.book-appointment-button:disabled {
  background: #edf2f7;
  color: #a0aec0;
  cursor: not-allowed;
  box-shadow: none;
}

.select-button {
  padding: 0.8rem 1.5rem;
  border: 2px solid rgba(213, 63, 140, 0.2);
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  background: white;
  color: #d53f8c;
  font-weight: 500;
}

.select-button:hover {
  background: linear-gradient(135deg, #d53f8c, #805ad5);
  color: white;
  border-color: transparent;
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(213, 63, 140, 0.2);
}

.select-button.selected {
  background: linear-gradient(135deg, #d53f8c, #805ad5);
  color: white;
  border-color: transparent;
  box-shadow: 0 8px 20px rgba(213, 63, 140, 0.2);
}

textarea {
  width: 100%;
  padding: 1rem;
  margin-bottom: 1.5rem;
  border: 2px solid rgba(213, 63, 140, 0.2);
  border-radius: 12px;
  resize: vertical;
  min-height: 100px;
  transition: all 0.3s ease;
  font-size: 1rem;
  color: #2d3748;
}

textarea:focus {
  outline: none;
  border-color: #d53f8c;
  box-shadow: 0 0 0 3px rgba(213, 63, 140, 0.1);
}
</style>